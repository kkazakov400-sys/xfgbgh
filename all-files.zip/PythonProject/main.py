"""
TON Wallet - Simple Version
Оптимизирован для сборки в APK
"""

import json
import os
from datetime import datetime
import random

from kivy.lang import Builder
from kivy.uix.screenmanager import ScreenManager, Screen
from kivy.properties import StringProperty, NumericProperty
from kivy.storage.jsonstore import JsonStore
from kivy.core.clipboard import Clipboard
from kivymd.app import MDApp
from kivymd.uix.dialog import MDDialog
from kivymd.uix.button import MDRaisedButton, MDFlatButton
from kivymd.uix.snackbar import Snackbar

# Загружаем интерфейс
KV = '''
<MainScreen>:
    BoxLayout:
        orientation: 'vertical'

        MDTopAppBar:
            title: "TON Wallet"
            elevation: 10
            left_action_items: [["menu", lambda x: root.open_menu()]]
            right_action_items: [["cog", lambda x: root.open_settings()]]

        ScrollView:
            BoxLayout:
                orientation: 'vertical'
                spacing: 20
                padding: 20
                size_hint_y: None
                height: self.minimum_height

                # Баланс
                MDCard:
                    orientation: 'vertical'
                    size_hint: 1, None
                    height: 150
                    padding: 20
                    elevation: 5

                    MDLabel:
                        text: "Ваш баланс"
                        font_style: 'Body1'
                        halign: 'center'

                    MDLabel:
                        id: balance_label
                        text: root.balance_text
                        font_style: 'H3'
                        halign: 'center'
                        bold: True

                    MDLabel:
                        id: usd_balance
                        text: root.usd_balance_text
                        font_style: 'Body2'
                        halign: 'center'

                # Кнопки действий
                GridLayout:
                    cols: 2
                    spacing: 15
                    size_hint: 1, None
                    height: 90

                    MDRaisedButton:
                        text: "Отправить"
                        on_release: root.open_send()

                    MDRaisedButton:
                        text: "Получить"
                        on_release: root.open_receive()

                # Адрес кошелька
                MDCard:
                    orientation: 'vertical'
                    size_hint: 1, None
                    height: 120
                    padding: 15

                    MDLabel:
                        text: "Адрес кошелька:"
                        font_style: 'Body2'
                        size_hint_y: None
                        height: 20

                    MDLabel:
                        id: address_label
                        text: root.wallet_address
                        font_style: 'Caption'
                        halign: 'center'
                        text_size: self.width, None

                    MDRaisedButton:
                        text: "Копировать адрес"
                        size_hint: None, None
                        size: 200, 40
                        pos_hint: {'center_x': 0.5}
                        on_release: root.copy_address()

                # История
                MDCard:
                    orientation: 'vertical'
                    size_hint: 1, None
                    height: 200
                    padding: 10

                    MDLabel:
                        text: "История транзакций"
                        font_style: 'H6'
                        size_hint_y: None
                        height: 30

                    ScrollView:
                        MDList:
                            id: transaction_list

<SendScreen>:
    BoxLayout:
        orientation: 'vertical'

        MDTopAppBar:
            title: "Отправить TON"
            left_action_items: [["arrow-left", lambda x: root.go_back()]]

        BoxLayout:
            orientation: 'vertical'
            spacing: 20
            padding: 20

            MDTextField:
                id: address_input
                hint_text: "Адрес получателя"
                size_hint_x: 1

            MDTextField:
                id: amount_input
                hint_text: "Сумма в TON"
                size_hint_x: 1
                input_filter: 'float'

            MDLabel:
                text: "Комиссия: 0.05 TON"
                font_style: 'Body2'

            MDRaisedButton:
                text: "Отправить"
                size_hint_x: 1
                on_release: root.send_ton()

<ReceiveScreen>:
    BoxLayout:
        orientation: 'vertical'

        MDTopAppBar:
            title: "Получить TON"
            left_action_items: [["arrow-left", lambda x: root.go_back()]]

        BoxLayout:
            orientation: 'vertical'
            spacing: 20
            padding: 20

            MDLabel:
                text: "Ваш адрес:"
                font_style: 'H6'
                halign: 'center'

            MDCard:
                orientation: 'vertical'
                size_hint: 1, None
                height: 80
                padding: 10

                MDLabel:
                    id: address_label
                    text: root.wallet_address
                    font_style: 'Caption'
                    halign: 'center'

            MDRaisedButton:
                text: "Копировать адрес"
                on_release: root.copy_address()

<SettingsScreen>:
    BoxLayout:
        orientation: 'vertical'

        MDTopAppBar:
            title: "Настройки"
            left_action_items: [["arrow-left", lambda x: root.go_back()]]

        ScrollView:
            BoxLayout:
                orientation: 'vertical'
                spacing: 20
                padding: 20
                size_hint_y: None
                height: 600

                MDLabel:
                    text: "Изменение баланса"
                    font_style: 'H6'

                MDTextField:
                    id: balance_input
                    hint_text: "Новый баланс"
                    text: str(root.current_balance)
                    size_hint_x: 1

                GridLayout:
                    cols: 3
                    spacing: 10
                    size_hint: 1, None
                    height: 50

                    MDRaisedButton:
                        text: "+10"
                        on_release: root.add_balance(10)

                    MDRaisedButton:
                        text: "+50"
                        on_release: root.add_balance(50)

                    MDRaisedButton:
                        text: "+100"
                        on_release: root.add_balance(100)

                MDRaisedButton:
                    text: "Обновить баланс"
                    size_hint_x: 1
                    on_release: root.update_balance()

                MDLabel:
                    text: "Другие настройки"
                    font_style: 'H6'

                MDRaisedButton:
                    text: "Создать новый кошелек"
                    on_release: root.create_new_wallet()

                MDRaisedButton:
                    text: "Очистить историю"
                    on_release: root.clear_history()
'''

Builder.load_string(KV)


class MainScreen(Screen):
    balance_text = StringProperty("0.00 TON")
    usd_balance_text = StringProperty("≈ $0.00")
    wallet_address = StringProperty("")

    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        self.app = MDApp.get_running_app()

    def on_enter(self):
        self.update_display()

    def update_display(self):
        wallet = self.app.store.get('wallet')
        balance = wallet['balance']
        self.balance_text = f"{balance:.2f} TON"
        self.usd_balance_text = f"≈ ${balance * 2.5:.2f}"
        self.wallet_address = wallet['address'][:30] + "..."
        self.load_transactions()

    def load_transactions(self):
        transaction_list = self.ids.transaction_list
        transaction_list.clear()

        transactions = self.app.store.get('wallet')['transactions']
        for transaction in reversed(transactions[-5:]):
            text = f"{transaction['type']} {transaction['amount']} TON"
            secondary = transaction['time']
            item = TwoLineListItem(text=text, secondary_text=secondary)
            transaction_list.add_widget(item)

    def copy_address(self):
        wallet = self.app.store.get('wallet')
        Clipboard.copy(wallet['address'])
        self.app.show_snackbar("Адрес скопирован")

    def open_menu(self):
        self.app.show_snackbar("Меню")

    def open_settings(self):
        self.manager.current = 'settings'

    def open_send(self):
        self.manager.current = 'send'

    def open_receive(self):
        self.manager.current = 'receive'


class SendScreen(Screen):
    def go_back(self):
        self.manager.current = 'main'

    def send_ton(self):
        address = self.ids.address_input.text.strip()
        amount_text = self.ids.amount_input.text.strip()

        if not address:
            self.app.show_snackbar("Введите адрес")
            return

        if not amount_text:
            self.app.show_snackbar("Введите сумму")
            return

        try:
            amount = float(amount_text)
            fee = 0.05

            app = MDApp.get_running_app()
            wallet = app.store.get('wallet')

            if amount + fee > wallet['balance']:
                app.show_snackbar("Недостаточно средств")
                return

            # Обновляем баланс
            wallet['balance'] -= (amount + fee)

            # Добавляем транзакцию
            transaction = {
                'type': 'send',
                'amount': amount,
                'address': address[:20],
                'time': datetime.now().strftime("%H:%M %d.%m"),
                'status': 'success'
            }
            wallet['transactions'].append(transaction)

            app.store.put('wallet', **wallet)
            app.show_snackbar(f"Отправлено {amount} TON")

            self.ids.address_input.text = ""
            self.ids.amount_input.text = ""

            self.manager.current = 'main'

        except ValueError:
            self.app.show_snackbar("Ошибка в сумме")


class ReceiveScreen(Screen):
    wallet_address = StringProperty("")

    def on_pre_enter(self):
        self.wallet_address = MDApp.get_running_app().store.get('wallet')['address']

    def go_back(self):
        self.manager.current = 'main'

    def copy_address(self):
        Clipboard.copy(self.wallet_address)
        MDApp.get_running_app().show_snackbar("Адрес скопирован")


class SettingsScreen(Screen):
    current_balance = NumericProperty(0)

    def on_pre_enter(self):
        self.current_balance = MDApp.get_running_app().store.get('wallet')['balance']
        self.ids.balance_input.text = str(self.current_balance)

    def go_back(self):
        self.manager.current = 'main'

    def add_balance(self, amount):
        try:
            current = float(self.ids.balance_input.text)
            self.ids.balance_input.text = str(current + amount)
        except:
            self.ids.balance_input.text = str(amount)

    def update_balance(self):
        try:
            new_balance = float(self.ids.balance_input.text)
            app = MDApp.get_running_app()
            wallet = app.store.get('wallet')

            difference = new_balance - wallet['balance']
            wallet['balance'] = new_balance

            # Добавляем запись в историю
            transaction = {
                'type': 'adjustment',
                'amount': abs(difference),
                'address': 'settings',
                'time': datetime.now().strftime("%H:%M %d.%m"),
                'status': 'adjusted'
            }
            wallet['transactions'].append(transaction)

            app.store.put('wallet', **wallet)
            app.show_snackbar(f"Баланс обновлен: {new_balance} TON")

        except ValueError:
            MDApp.get_running_app().show_snackbar("Ошибка ввода")

    def create_new_wallet(self):
        import hashlib
        import uuid

        app = MDApp.get_running_app()
        address = f"EQ{hashlib.md5(str(uuid.uuid4()).encode()).hexdigest()[:48].upper()}"

        wallet_data = {
            'address': address,
            'balance': 100.0,
            'transactions': [{
                'type': 'welcome',
                'amount': 100.0,
                'address': 'Новый кошелек',
                'time': datetime.now().strftime("%H:%M %d.%m"),
                'status': 'created'
            }]
        }

        app.store.put('wallet', **wallet_data)
        app.show_snackbar("Новый кошелек создан")
        self.manager.current = 'main'

    def clear_history(self):
        app = MDApp.get_running_app()
        wallet = app.store.get('wallet')
        wallet['transactions'] = []
        app.store.put('wallet', **wallet)
        app.show_snackbar("История очищена")


class TONWalletApp(MDApp):
    def build(self):
        self.theme_cls.primary_palette = "Blue"
        self.theme_cls.theme_style = "Dark"

        # Инициализация хранилища
        self.store = JsonStore('ton_wallet.json')
        self.init_wallet()

        # Создаем экраны
        sm = ScreenManager()
        sm.add_widget(MainScreen(name='main'))
        sm.add_widget(SendScreen(name='send'))
        sm.add_widget(ReceiveScreen(name='receive'))
        sm.add_widget(SettingsScreen(name='settings'))

        return sm

    def init_wallet(self):
        if not self.store.exists('wallet'):
            import hashlib
            import uuid

            address = f"EQ{hashlib.md5(str(uuid.uuid4()).encode()).hexdigest()[:48].upper()}"

            wallet_data = {
                'address': address,
                'balance': 1000.0,
                'transactions': [
                    {
                        'type': 'receive',
                        'amount': 1000.0,
                        'address': 'Начальный баланс',
                        'time': datetime.now().strftime("%H:%M %d.%m"),
                        'status': 'completed'
                    }
                ]
            }
            self.store.put('wallet', **wallet_data)

    def show_snackbar(self, message):
        Snackbar(text=message).open()


def main():
    TONWalletApp().run()


if __name__ == '__main__':
    main()