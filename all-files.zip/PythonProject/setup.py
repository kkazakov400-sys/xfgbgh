from setuptools import setup

setup(
    name='ton_wallet',
    version='1.0',
    description='TON Wallet App',
    author='TON Developer',
    packages=[],
    install_requires=[
        'kivy>=2.1.0',
        'kivymd>=1.1.1',
    ]
)